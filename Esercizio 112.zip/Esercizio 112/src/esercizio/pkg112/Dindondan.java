/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package esercizio.pkg112;

/**
 *
 * @author Asus
 */
public class Dindondan {
    public static void main(String args[]){
        Runnable cam1 = new Campana("din",5);
        Thread thr1 = new Thread(cam1);
        thr1.start();
        
        Thread thr2 = new Thread(new Campana("don",5));
        thr2.start();
        
        new Thread (new Campana("dan",5)).start();
    }
}
